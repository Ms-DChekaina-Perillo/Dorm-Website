<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    echo "Form submitted successfully. Name: " . htmlspecialchars($name);
}
?>
