<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get data from form
    $name = $_POST['name'];
    $gmail = $_POST['gmail'];
    $contact = $_POST['contact'];
    $password = $_POST['password'];

    // Database connection (with port 3307)
    $conn = new mysqli("localhost", "root", "", "dorm_website_db", 3307);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind SQL statement
    $stmt = $conn->prepare("INSERT INTO users (name, gmail, contact, password) VALUES (?, ?, ?, ?)");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("ssss", $name, $gmail, $contact, $password);

    // Execute the statement and check for success
    if ($stmt->execute()) {
        // Redirect to login page after successful sign-up
        header("Location: login.html");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>
