<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $gmail = $_POST['gmail'];
    $password = $_POST['password'];

    // Database connection
    $conn = new mysqli("localhost", "root", "", "dorm_website_db", 3307);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Validate user credentials
    $stmt = $conn->prepare("SELECT * FROM users WHERE gmail = ? AND password = ?");
    $stmt->bind_param("ss", $gmail, $password);
    $stmt->execute();

    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        echo "Login successful! Welcome back.";
    } else {
        echo "Invalid email or password.";
    }

    $stmt->close();
    $conn->close();
}
?>
